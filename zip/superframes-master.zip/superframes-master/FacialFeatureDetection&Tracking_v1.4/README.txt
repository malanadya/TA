Intraface
http://www.humansensing.cs.cmu.edu/intraface/index.php
http://www.humansensing.cs.cmu.edu/intraface/download_functions_matlab.html